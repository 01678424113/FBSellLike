<div id="b-c-facebook" class="chat_f_vt" style="display: block;">
    <div id="chat-f-b" onclick="chat_f_close()" class="chat-f-b">
        <label id="f_chat_name">Chat với chúng tôi!</label><span id="fb_alert_num" style="display: block;">1</span>
        <div id="t_f_chat">
            <a href="javascript:;" onclick="chat_f_close()" id="chat_f_close"></a>
        </div>
    </div>
    <div id="f-chat-conent" class="f-chat-conent">
        <div id="fb-root"></div>
        <div class="fb-page fb_iframe_widget" data-tabs="messages" data-href="https://www.facebook.com/hotronguoidung" data-width="300" data-height="335" data-small-header="true" data-adapt-container-width="true" data-hide-cover 'false'="" data-show-facepile="true" data-show-posts="false" fb-xfbml-state="rendered" fb-iframe-plugin-query="adapt_container_width=true&amp;app_id=395425544128333&amp;container_width=0&amp;height=335&amp;href=https%3A%2F%2Fwww.facebook.com%2Fkeywebvn&amp;locale=vi_VN&amp;sdk=joey&amp;show_facepile=true&amp;show_posts=false&amp;small_header=true&amp;tabs=messages&amp;width=300"><span style="vertical-align: bottom; width: 300px; height: 335px;"><iframe name="f12d0ebbec55a5c" width="300px" height="335px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" title="fb:page Facebook Social Plugin" src="https://www.facebook.com/v2.11/plugins/page.php?adapt_container_width=true&amp;app_id=395425544128333&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter%2Fr%2FlY4eZXm_YWu.js%3Fversion%3D42%23cb%3Dfe33c1b9486a%26domain%3Dkeyweb.vn%26origin%3Dhttps%253A%252F%252Fkeyweb.vn%252Ff2cb1e2e41f23b%26relation%3Dparent.parent&amp;container_width=0&amp;height=335&amp;href=https%3A%2F%2Fwww.facebook.com%2Fkeywebvn&amp;locale=vi_VN&amp;sdk=joey&amp;show_facepile=true&amp;show_posts=false&amp;small_header=true&amp;tabs=messages&amp;width=300" style="border: none; visibility: visible; width: 300px; height: 335px;" class=""></iframe></span>
        </div>
        <div id="fb_chat_start" style="display: block;">
            <div class="msg_b">Liên hệ với chúng tôi nếu bạn cần tư vấn nhé!</div>
            <br>
            <p id="f_bt_chat" class="fb_hide" style="display: block;"><a href="javascript:;" onclick="f_bt_start_chat()" id="f_bt_start_chat">Bắt đầu Chat</a>
            </p>
            <br>
            <p id="f_bt_note" class="fb_hide" style="display: block;">Chú ý: Bạn phải đăng nhập <a href="http://facebook.com/" target="_blank" rel="nofollow">Facebook</a> mới có thể trò chuyện.</p>
        </div>
    </div>
</div>