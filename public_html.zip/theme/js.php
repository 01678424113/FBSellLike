<!-- Mainly scripts -->
<link rel="stylesheet" href="<?php $home; ?>/theme/lol.css" property="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script type="text/javascript"src="<?php $home; ?>/theme/toastr.min.js"></script>
<script type="text/javascript"src="<?php $home; ?>/theme/app.js"></script>
<script type="text/javascript"src="<?php $home; ?>/theme/thang.php"></script>
<script type="text/javascript"src="<?php $home; ?>/theme/jquery.dataTables.min.js"></script>
<script type="text/javascript"src="<?php $home; ?>/theme/dataTables.bootstrap.min.js"></script>
<script src="<?php echo $home; ?>/theme/dist/sweetalert.min.js"></script>
<script type="text/javascript"src="<?php $home; ?>/theme/table.js"></script>

        