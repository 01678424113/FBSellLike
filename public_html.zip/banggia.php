<?php

include 'like_hethong/head.php';
include 'like_hethong/functions.php';
?>


<!DOCTYPE html>
<html lang="vi">
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <title>Bảng Giá - VIPFBNOW.COM</title>
    <link rel="shortcut icon" href="https://i.imgur.com/h6NWYI8.png">
    <meta property="og:image" content="http://i.imgur.com/JA3DwPC.jpg" />
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />	
 <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>

<div class="col-lg-12">
<div class="alert alert-danger">
     <strong><marquee>BẢNG GIÁ HỆ THỐNG VIP TẠI VIPFBNOW.COM - ĐẠI LÝ + CTV VUI LÒNG INBOX ADMIN ĐỂ NHẬN ĐƯỢC ƯU ĐÃI HẤP DẪN</marquee></strong>   
</div>
<div class="small-box bg-red"><h4><center> NẠP DƯỚI 300K KHUYẾN MÃI 50% - NẠP TRÊN 300K KHUYẾN MÃI 100% GIÁ TRỊ THẺ NẠP - CHỈ ÁP DỤNG VỚI HÌNH THỨC NẠP QUA MEGA VÀ VIETCOMBANK </h4></div>
                        <button type="button" class="close" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body">
                        <ul class="nav nav-tabs">
                            <li class="active">
                                <a href="#like" data-toggle="tab">VIP LIKE</a>
                            </li>
                            <li><a href="#cmt" data-toggle="tab">VIP COMMENT</a>
                            </li>
                            <li><a href="#reaction" data-toggle="tab">VIP REACTION</a>
                            </li>
                            <li><a href="#share" data-toggle="tab">BOT COMMENT</a>
                            </li>
							 <li><a href="#dvkhac" data-toggle="tab">DỊCH VỤ KHÁC</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="like">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <tbody><tr style="color:red">
                                            <th>ID</th>
											<th>Max Like</th>
                                            <th>Limit Post</th>
                                            <th>Thời Hạn</th>
											<th>Giá Tiền</th>
                                        </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>Like 1</td>
                                                <td>150 Likes/Post</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>30,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>Like 2</td>
                                                <td>300 Likes/Post</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>50,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>Like 3</td>
                                                <td>500 Likes/Post</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>80,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>Like 4</td>
                                                <td>700 Likes/Post</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>120,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>Like 5</td>
                                                <td>1000 Likes/Post</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>170,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>Like 6</td>
                                                <td>1500 Likes/Post</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>250,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>Like 7</td>
                                                <td>2000 Likes/Post</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>340,000 VNĐ</td>
                                            </tr>
                                                                            </tbody></table>
                                </div>
                            </div>

                            <div class="tab-pane" id="cmt">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <tbody><tr style="color:red">
                                            <th>ID</th>
											<th>Max CMT</th>
                                            <th>Limit Post</th>
                                            <th>Thời Hạn</th>
											<th>Giá Tiền</th>
                                        </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>CMT 1</td>
                                                <td>20 CMT</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>30,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>CMT 2</td>
                                                <td>40 CMT</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>60,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>CMT 3</td>
                                                <td>80 CMT</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>120,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>CMT 4</td>
                                                <td>120 CMT</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>180,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>CMT 5</td>
                                                <td>180 CMT</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>270,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>CMT 6</td>
                                                <td>240 CMT</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>360,000 VNĐ</td>
                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>CMT 7</td>
                                                <td>320 CMT</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>480,000 VNĐ</td>
                                            </tr>
											
											                                            </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>CMT 8</td>
                                                <td>500 CMT</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>750,000 VNĐ</td>
                                            </tr>
                   
                                                                            </tbody></table>
                                </div>
                            </div>
                            <div class="tab-pane" id="reaction">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <tbody><tr style="color:red">
											<th>ID</th>
										    <th>Số Cảm Xúc</th>
                                            <th>Limit Post</th>
                                            <th>Thời Hạn</th>
											<th>Giá Tiền</th>
                                        </tr>
                                                                                    <tr style="font-weight: bold">
                                                <td>Bot CX 1</td>
                                                <td>Không Giới Hạn</td>
                                                <td>Không Giới Hạn</td>
                                                <td>1 Tháng</td>
                                                <td>20,000 VNĐ</td>
                                            </tr>
                                                                            </tbody></table>
                                </div>
                            </div>

                            <div class="tab-pane" id="share">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <tbody><tr style="color:red">
                                            <th>ID</th>
											<th>Số Comment</th>
                                            <th>Limit Post</th>
                                            <th>Thời Hạn</th>
											<th>Giá Tiền</th>
                                        </tr>                                                                                    
										<tr style="font-weight: bold">                                                
										<td>Bot CMT 1</td>                                                
										<td>Không Giới Hạn</td>                                                
										<td>Không Giới Hạn</td>                                                
										<td>1 Tháng</td>                                                
										<td>20,000 VNĐ</td>
										</tr>

                                                                            </tbody></table>
								</div>
                            </div>
								<div class="tab-pane" id="dvkhac">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <tbody><tr style="color:red">
<h4>Tăng Like FanPage: 				100k/1k Like</h4>
<h4>Tăng Đánh Giá 5* FanPage:   	100k/1k Đánh giá</h4>
<h4>Tăng Sub ( Người theo dõi ):	50k/1k Người</h4>
                                        </tr>

                                                                            </tbody></table>
          </div>
   </div></div></div></div>
<?php
include 'like_hethong/foot.php';
?>
